"""Prevent concurrent workflows from overwriting shared results and task logs."""
from __future__ import annotations

from contextlib import ExitStack
from functools import wraps
import errno
import json
import os
from pathlib import Path
import socket
import sys


class RunLock:
    def __init__(self, path: Path):
        self.path = path
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.handle.close()
            self.handle = None
            if exc.errno not in {errno.EACCES, errno.EAGAIN}:
                raise RuntimeError(f"Cannot acquire workflow lock {self.path}: {exc}; no workflow task was started.") from exc
            try:
                with self.path.open("rb") as handle:
                    # Windows excludes reads of byte 0 through other handles.
                    # Owner metadata starts after that locked byte.
                    handle.seek(1)
                    owner = json.loads(handle.read().decode("utf-8"))
                detail = f"host={owner.get('host', '?')}, pid={owner.get('pid', '?')}"
            except (OSError, ValueError, AttributeError):
                detail = "owner unavailable"
            raise RuntimeError(
                f"Another workflow is using this output or temporary workspace ({detail}); "
                f"lock={self.path}. Wait for that run to finish or stop it before restarting."
            ) from exc
        try:
            self.handle.seek(0)
            self.handle.truncate()
            self.handle.write((" " + json.dumps({"pid": os.getpid(), "host": socket.gethostname()}) + "\n").encode())
            self.handle.flush()
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *_):
        if self.handle is not None:
            try:
                if os.name == "nt":
                    import msvcrt
                    self.handle.seek(0)
                    msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            finally:
                self.handle.close()
                self.handle = None
        # Keep the inode: unlinking a lock file could let another process
        # acquire a different inode while an existing owner still holds it.


def active_assemblers(roots: tuple[Path, ...], proc_root: Path = Path("/proc")) -> list[tuple[int, Path]]:
    """Find older MEGAHIT/Flye writers, including runs predating workflow locks."""
    if not roots or not proc_root.is_dir():
        return []
    roots = tuple(path.resolve() for path in roots)
    found: list[tuple[int, Path]] = []
    for process in proc_root.iterdir():
        if not process.name.isdigit() or int(process.name) == os.getpid():
            continue
        try:
            argv = [value.decode(errors="replace") for value in (process / "cmdline").read_bytes().split(b"\x00") if value]
            names = [Path(value).name.lower() for value in argv[:3]]
            if not any(name in {"megahit", "flye"} or name.startswith(("megahit_core", "flye-")) for name in names):
                continue
            destinations = []
            for index, value in enumerate(argv):
                option, separator, attached = value.partition("=")
                if option in {"--out-dir", "--outdir", "-o"}:
                    destination = attached if separator else (argv[index + 1] if index + 1 < len(argv) else "")
                    if destination:
                        target = Path(destination)
                        if not target.is_absolute():
                            target = (process / "cwd").resolve() / target
                        destinations.append(target.resolve())
            for root in roots:
                if any(target == root or root in target.parents for target in destinations):
                    found.append((int(process.name), root))
        except (OSError, ValueError):
            continue
    return found


def exclusive_workflow(function):
    """Lock the output/temp directories supplied to the CLI task runner."""
    @wraps(function)
    def wrapped(args, tasks, output, temp_files, *positional, **keywords):
        if getattr(args, "dry_run", False):
            return function(args, tasks, output, temp_files, *positional, **keywords)
        lock_output = Path(output).expanduser().resolve()
        workspace = Path(temp_files).expanduser().resolve()
        paths = {
            lock_output / ".metabaw.run.lock",
            workspace.parent / f".{workspace.name}.metabaw.run.lock",
        }
        with ExitStack() as stack:
            for path in sorted(paths, key=str):
                stack.enter_context(RunLock(path))
            roots = tuple(task.outputs[0].parent for task in tasks
                          if task.id.startswith(("01.assemble.", "01.coassemble.")) and task.outputs)
            active = active_assemblers(roots) if sys.platform.startswith("linux") else []
            if active:
                owners = ", ".join(f"pid={pid}, directory={root}" for pid, root in active)
                raise RuntimeError(
                    f"MEGAHIT/Flye is still writing to an assembly directory: {owners}. "
                    "Wait for the existing run to finish or stop it before restarting; "
                    "no workflow task was started."
                )
            return function(args, tasks, output, temp_files, *positional, **keywords)
    return wrapped
