"""Bounded annotation batches and disk-backed result joins/sorting."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import csv
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import tempfile
import sys


def format_functional_table(input_path: Path, gene_maps: list[str], output: Path,
                            kind: str, ko_descriptions: Path | None = None) -> None:
    from .internal import (_labeled_paths, FUNCTIONAL_PREFIX_COLUMNS, read_kegg_descriptions,
                           _functional_query_field, _functional_annotation_value)

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".annotation-format-", dir=output.parent) as temporary:
        database = sqlite3.connect(str(Path(temporary) / "join.sqlite3"))
        try:
            database.execute("PRAGMA cache_size=-8192")
            database.execute("PRAGMA temp_store=FILE")
            database.execute("PRAGMA journal_mode=OFF")
            database.execute("CREATE TABLE mapping (label TEXT, protein TEXT, payload TEXT, PRIMARY KEY(label,protein))")
            for genome, path in _labeled_paths(gene_maps):
                with path.open(encoding="utf-8-sig", newline="") as handle:
                    for row in csv.DictReader(handle, delimiter="\t"):
                        protein = str(row.get("Protein_id") or "")
                        if not protein:
                            raise ValueError(f"Functional gene map lacks Protein_id: {path}")
                        try:
                            database.execute("INSERT INTO mapping VALUES (?,?,?)",
                                             (genome, protein, json.dumps(row, ensure_ascii=False)))
                        except sqlite3.IntegrityError as exc:
                            raise ValueError(f"Duplicate functional gene mapping: {genome}/{protein}") from exc
            database.execute("CREATE INDEX protein_mapping ON mapping(protein)")
            database.execute("CREATE TABLE formatted (mag TEXT, contig TEXT, gene TEXT, payload TEXT)")
            descriptions = read_kegg_descriptions(ko_descriptions) if kind == "kegg" and ko_descriptions is not None else None
            additional = ["KO_gene_name", "KO_description"] if descriptions is not None else []
            missing_kos = set()
            with input_path.open(encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle, delimiter="\t")
                fields = [str(field) for field in (reader.fieldnames or ()) if field]
                query = _functional_query_field(kind, fields)
                for row in reader:
                    genome = str(row.get("Genome") or row.get("MAG") or "")
                    protein = str(row.get(query) or "")
                    match = database.execute("SELECT payload FROM mapping WHERE label=? AND protein=?",
                                             (genome, protein)).fetchone()
                    if match is None:
                        matches = database.execute("SELECT payload FROM mapping WHERE protein=? LIMIT 2", (protein,)).fetchall()
                        match = matches[0] if len(matches) == 1 else None
                    if match is None:
                        raise ValueError(f"No MAG/contig mapping for functional gene {genome}/{protein}")
                    mapped = json.loads(match[0])
                    annotation, annotation_field = _functional_annotation_value(kind, row)
                    excluded = {"Genome", "MAG", query, annotation_field}
                    extras = {field: str(row.get(field) or "") for field in fields if field not in excluded}
                    additional.extend(field for field in extras if field not in additional and field not in FUNCTIONAL_PREFIX_COLUMNS)
                    result = {
                        "MAG": str(mapped["MAG"]), "MAG_contig_raw_id": str(mapped["MAG_contig_raw_id"]),
                        "MAG_contig_id": str(mapped["MAG_contig_id"]), "MAG_contig_gene_id": str(mapped["MAG_contig_gene_id"]),
                        "Gene": annotation, **extras,
                    }
                    if descriptions is not None:
                        description = descriptions.get(annotation, "NA")
                        result["KO_gene_name"] = description.split(";", 1)[0].strip() if description != "NA" else "NA"
                        result["KO_description"] = description
                        ko = str(row.get("KO") or "").strip()
                        if ko and ko not in descriptions:
                            missing_kos.add(ko)
                    database.execute("INSERT INTO formatted VALUES (?,?,?,?)", (
                        result["MAG"], result["MAG_contig_id"], result["MAG_contig_gene_id"], json.dumps(result, ensure_ascii=False)))
            if missing_kos:
                values = sorted(missing_kos)
                preview = ", ".join(values[:10]) + (f", +{len(values) - 10} more" if len(values) > 10 else "")
                print(f"[WARNING] K.descript.txt lacks descriptions for {len(values)} annotated KO(s); "
                      f"writing NA to KO_gene_name and KO_description; missing={preview}; file={ko_descriptions}", file=sys.stderr)
            database.commit()
            with output.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=(*FUNCTIONAL_PREFIX_COLUMNS, *additional),
                                        delimiter="\t", lineterminator="\n", extrasaction="ignore")
                writer.writeheader()
                for (payload,) in database.execute("SELECT payload FROM formatted ORDER BY mag,contig,gene,rowid"):
                    writer.writerow(json.loads(payload))
        finally:
            database.close()


def run_prediction_batch(items: list[str], proteins_dir: Path, gene_maps_dir: Path,
                         jobs: int, threads: int) -> None:
    from .internal import (_labeled_paths, build_functional_gene_map, FUNCTIONAL_PREFIX_COLUMNS)
    from .model import Task
    from .output_validation import result_errors
    from .named_inputs import genome_name

    if jobs < 1 or threads < 1:
        raise ValueError("Prediction batch jobs/threads must be positive")
    records = _labeled_paths(items)
    if any(genome != genome_name(source) for genome, source in records):
        raise ValueError("Prediction batch labels must match their MAG filenames")
    proteins_dir.mkdir(parents=True, exist_ok=True)
    gene_maps_dir.mkdir(parents=True, exist_ok=True)

    def process(record):
        genome, source = record
        proteins = proteins_dir / f"{genome}.faa"
        gene_map = gene_maps_dir / f"{genome}.tsv"
        protein_task = Task("protein", "annotation", "unused", proteins_dir, outputs=(proteins,))
        if result_errors(protein_task):
            executable = shutil.which("prodigal")
            if executable is None:
                raise ValueError("prodigal was not found in PATH")
            native = subprocess.run([executable, "-q", "-p", "single", "-i", str(source),
                                     "-a", str(proteins)], capture_output=True, text=True)
            if native.returncode:
                raise RuntimeError(f"Prodigal failed for {genome}: {native.stderr.strip()}")
        map_ready = False
        try:
            with gene_map.open(encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle, delimiter="\t")
                first = next(reader, {})
                map_ready = (set((*FUNCTIONAL_PREFIX_COLUMNS[:-1], "Protein_id")) <= set(reader.fieldnames or ())
                             and first.get("MAG") == genome and bool(first.get("Protein_id")))
        except OSError:
            pass
        if not map_ready:
            build_functional_gene_map(source, proteins, genome, gene_map)

    print(f"[PREDICTION BATCH] genomes={len(records)}; jobs={min(jobs, threads)}", flush=True)
    with ThreadPoolExecutor(max_workers=min(jobs, threads)) as pool:
        for _ in pool.map(process, records):
            pass


def merge_functional_tables(paths: list[Path], output: Path) -> None:
    from .internal import FUNCTIONAL_PREFIX_COLUMNS

    output.parent.mkdir(parents=True, exist_ok=True)
    fields = list(FUNCTIONAL_PREFIX_COLUMNS)
    for path in paths:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            header = next(csv.reader(handle, delimiter="\t"), [])
        if not set(FUNCTIONAL_PREFIX_COLUMNS) <= set(header):
            raise ValueError(f"Incomplete functional batch table: {path}")
        fields.extend(field for field in header if field not in fields)
    with tempfile.TemporaryDirectory(prefix=".annotation-merge-", dir=output.parent) as temporary:
        database = sqlite3.connect(str(Path(temporary) / "rows.sqlite3"))
        try:
            database.execute("PRAGMA cache_size=-8192")
            database.execute("PRAGMA temp_store=FILE")
            database.execute("PRAGMA journal_mode=OFF")
            database.execute("CREATE TABLE rows (mag TEXT, contig TEXT, gene TEXT, payload TEXT)")
            for path in paths:
                with path.open(encoding="utf-8-sig", newline="") as handle:
                    reader = csv.DictReader(handle, delimiter="\t")
                    database.executemany("INSERT INTO rows VALUES (?,?,?,?)", (
                        (row["MAG"], row["MAG_contig_id"], row["MAG_contig_gene_id"], json.dumps(row, ensure_ascii=False))
                        for row in reader))
            database.commit()
            with output.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
                writer.writeheader()
                for (payload,) in database.execute("SELECT payload FROM rows ORDER BY mag,contig,gene,rowid"):
                    writer.writerow(json.loads(payload))
        finally:
            database.close()


def merge_gtdb_batches(directories: list[Path], output: Path, genomes: list[Path]) -> None:
    from .internal import _gtdbtk_summary_files, gtdbtk_result_missing

    output.mkdir(parents=True, exist_ok=True)
    members = {"bac120": [], "ar53": []}
    for directory in directories:
        for path in _gtdbtk_summary_files(directory):
            domain = "bac120" if ".bac120." in path.name else "ar53"
            members[domain].append(path)
    for domain, paths in members.items():
        if not paths:
            continue
        target = output / f"gtdbtk.{domain}.summary.tsv"
        header = None
        with target.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
            for path in paths:
                with path.open(encoding="utf-8-sig", newline="") as source:
                    reader = csv.reader(source, delimiter="\t")
                    fields = next(reader, [])
                    if header is None:
                        header = fields
                        writer.writerow(header)
                    elif fields != header:
                        raise ValueError(f"GTDB-Tk batch summary columns differ: {path}")
                    writer.writerows(reader)
    missing = gtdbtk_result_missing(output, genomes)
    if missing:
        raise ValueError("Merged GTDB-Tk batches are incomplete: " + "; ".join(missing))
    (output / ".metabaw.complete").write_text("GTDB-Tk batch summaries validated\n", encoding="utf-8")
