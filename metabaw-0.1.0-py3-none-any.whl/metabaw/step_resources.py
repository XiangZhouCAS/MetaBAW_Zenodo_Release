"""Allocate current-step budgets and adjust only known native resource options."""
from __future__ import annotations

from dataclasses import replace
import json
import re
import shlex

from .model import Task
from .resume import THREAD_ENVIRONMENT, THREAD_OPTIONS, _program


_WORDS = re.compile(r'''(?:'[^']*'|"(?:\\.|[^"\\])*"|\\.|[^\s;&|()<>'"\\])+|[;&|()<>]+''')


def retarget_threads(command: str, threads: int, depth: int = 0) -> str:
    """Preserve shell syntax/paths verbatim; replace known numeric thread values."""
    if depth > 3:
        raise ValueError("Resource command nesting exceeds the supported depth")
    matches = list(_WORDS.finditer(command))
    edits = []
    segments = [[]]
    for match in matches:
        if re.fullmatch(r"[;&|()<>]+", match.group()):
            segments.append([])
        else:
            segments[-1].append(match)
    for segment in segments:
        tokens = [shlex.split(match.group())[0] for match in segment]
        program, start = _program(tokens)
        options = THREAD_OPTIONS.get(program, set()) - {"--pplacer_cpus", "--pplacer-threads"}
        index = start
        while index < len(tokens):
            token = tokens[index]
            option, separator, value = token.partition("=")
            value_index = index
            if option in options and not separator and index + 1 < len(tokens):
                value_index = index + 1
                value = tokens[value_index]
            if option in options and value.isdecimal():
                # GNU parallel/exec_annotation deliberately use one HMMER thread
                # per worker. Their job count, rather than each worker, scales.
                fixed_worker = program == "hmmsearch" and value == "1" and ("parallel " in command or "exec_annotation " in command)
                if not fixed_worker:
                    replacement = f"{option}={threads}" if separator else str(threads)
                    edits.append((segment[value_index].start(), segment[value_index].end(), replacement))
                index = value_index + 1
                continue
            attached = next((flag for flag in options if not flag.startswith("--") and token.startswith(flag)
                             and token[len(flag):].isdecimal()), None)
            if attached:
                edits.append((segment[index].start(), segment[index].end(), f"{attached}{threads}"))
            if program == "metabaw.internal" and option in {"--command", "--native-command"}:
                value_index = index if separator else index + 1
                if value_index < len(tokens):
                    nested = value if separator else tokens[value_index]
                    if option == "--native-command":
                        arguments = json.loads(nested)
                        updated = json.dumps(shlex.split(retarget_threads(shlex.join(arguments), threads, depth + 1)))
                    else:
                        updated = retarget_threads(nested, threads, depth + 1)
                    if updated != nested:
                        replacement = shlex.quote(option + "=" + updated) if separator else shlex.quote(updated)
                        edits.append((segment[value_index].start(), segment[value_index].end(), replacement))
                    index = value_index
            index += 1
    for start, end, replacement in sorted(edits, reverse=True):
        command = command[:start] + replacement + command[end:]
    return command


def step_uses_total_budget(task: Task) -> bool:
    """Refinement/QC/dereplication and cohort tasks use the aggregate budget."""
    return task.sample is None or task.stage.startswith(("04_refinement", "05_quality", "06_dereplication"))


def allocate_task(task: Task, threads: int, memory_gib: float | None) -> Task:
    command = retarget_threads(task.display_command(), threads)
    if not isinstance(task.command, str):
        command = tuple(shlex.split(command))
    environment = dict(task.env)
    for key in THREAD_ENVIRONMENT:
        if environment.get(key) == str(task.cpus) and task.cpus != 1:
            environment[key] = str(threads)
    return replace(task, command=command, cpus=threads, memory_limit_gb=memory_gib, env=environment)
