"""COMEBin 1.1.0 runtime contract from its upstream Bioconda recipe.

https://github.com/bioconda/bioconda-recipes/blob/master/recipes/comebin/meta.yaml
https://github.com/ziyewang/COMEBin/blob/1.1.0/README.md
"""

COMEBIN_VERSION = "1.1.0"
COMEBIN_PYTHON_VERSION = "3.11"
COMEBIN_PYTHON_VERSIONS = ("3.11", "3.12", "3.13")
COMEBIN_ENVIRONMENT = "metabaw-comebin-py311"
COMEBIN_RUNTIME_PACKAGES = (
    "comebin=1.1.0",
    "bedtools>=2.31,<3", "biolib>=0.1.9,<0.2", "biopython>=1.85,<2",
    "bwa>=0.7.17,<0.8", "checkm-genome=1.2.5", "click>=8,<9",
    "fraggenescan>=1.31,<2", "hmmer=3.4", "hnswlib>=0.8,<1",
    "leidenalg>=0.12,<0.13", "numpy>=2,<3", "perl", "pplacer=1.1.alpha19",
    "prodigal=2.6.3", "python-igraph>=1,<2", "pytorch>=2.13,<2.14",
    "pyyaml>=6,<7", "samtools=1.21", "scikit-learn>=1.5,<1.10",
    "scipy>=1.13,<2", "setuptools<82", "tensorboard>=2.18,<3", "tqdm>=4.66,<5",
)
