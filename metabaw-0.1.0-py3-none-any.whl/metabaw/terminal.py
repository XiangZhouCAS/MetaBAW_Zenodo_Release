"""Terminal status colors and columns measured without escape sequences."""
from __future__ import annotations

import os
import re
import shutil
import sys
import unicodedata


_ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def plain_text(text: str) -> str:
    return _ANSI.sub("", text)


def status_tag(state: str, width: int = 0, stream=None) -> str:
    label = f"[{state}]"
    stream = sys.stdout if stream is None else stream
    color = ("31" if state.endswith("MISSING") or state in {"BROKEN", "NO DATA"} else
             "33" if state == "TIMEOUT" else
             "32" if state.endswith("OK") else None)
    if (color and getattr(stream, "isatty", lambda: False)()
            and "NO_COLOR" not in os.environ and os.environ.get("TERM") != "dumb"):
        rendered = f"\x1b[{color}m{label}\x1b[0m"
    else:
        rendered = label
    return rendered + " " * max(0, width - len(label))


def status_row(state: str, name: str, description: str, name_width: int = 34) -> str:
    # Keep one space after the tag; compensate for short tags after the name.
    name_width += max(0, 9 - len(f"[{state}]"))
    return f"{status_tag(state)} {name:<{name_width}} {description}"


def _columns(character: str) -> int:
    if unicodedata.combining(character):
        return 0
    return 2 if unicodedata.east_asian_width(character) in {"W", "F"} else 1


def _fit_progress(text: str, width: int) -> str:
    text = plain_text(text).replace("\r", " ").replace("\n", " ")
    if sum(map(_columns, text)) <= width:
        return text
    suffix = "." * min(3, width)
    used = 0
    prefix = []
    for character in text:
        used += _columns(character)
        if used > width - len(suffix):
            break
        prefix.append(character)
    return "".join(prefix) + suffix


class ProgressLine:
    """Refresh a single terminal row; keep only one snapshot per group in files."""

    def __init__(self):
        self.stream = sys.stdout
        self.interactive = (getattr(self.stream, "isatty", lambda: False)()
                            and os.environ.get("TERM") != "dumb")
        self.seen = set()
        self.key = None
        self.width = 0
        self.active = False

    def update(self, key, text: str) -> None:
        if not self.interactive:
            if key not in self.seen:
                print(text, file=self.stream, flush=True)
                self.seen.add(key)
            return
        if self.active and key != self.key:
            self.finish()
        # Leave the last column unused to prevent automatic line wrapping.
        columns = max(0, shutil.get_terminal_size(fallback=(120, 24)).columns - 1)
        fitted = _fit_progress(text, columns)
        width = sum(map(_columns, fitted))
        padding = max(0, min(self.width, columns) - width)
        self.stream.write("\r" + fitted + " " * padding)
        self.stream.flush()
        self.key, self.width, self.active = key, width, True

    def finish(self) -> None:
        if self.active:
            self.stream.write("\n")
            self.stream.flush()
            self.active = False
            self.width = 0
