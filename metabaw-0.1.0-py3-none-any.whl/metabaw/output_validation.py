"""Lightweight result checks for outputs-first workflow continuation.

These checks examine final files, not input timestamps, command hashes, or
database versions. They deliberately do not reread entire BAM/FASTA files.
"""
from __future__ import annotations

import gzip
import json
from pathlib import Path
import re
import shlex

from .model import Task, annotation_task_id
from .binner_completion import empty_mapping_marker, read_empty_binner
from .refinement import read_empty_refinement


FASTA_SUFFIXES = (".fa", ".fna", ".fasta", ".faa", ".fa.gz", ".fna.gz", ".fasta.gz", ".faa.gz")
BAM_EOF = bytes.fromhex("1f8b08040000000000ff0600424302001b0003000000000000000000")
EMPTY_SEARCH_TASKS = {
    "06.annotation.kegg", "08.annotation.hydrogenase.search",
    "08.annotation.hydrogenase.filter", "08.annotation.hydrogenase.fefe",
    "09.annotation.terminal.search",
}


def _marker(path: Path) -> bool:
    return path.name.endswith((".complete", ".done", ".ok"))


def _head(path: Path) -> str:
    opener = gzip.open if path.name.lower().endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8-sig", errors="replace") as handle:
        return handle.read(8192)


def _table_error(path: Path, required: set[str]) -> str | None:
    lines = [line for line in _head(path).splitlines() if line.strip() and not line.startswith("#")]
    if not lines:
        return f"{path} (result table has no header)"
    columns = {value.strip().lower().replace(" ", "_") for value in lines[0].split("\t")}
    if not required <= columns:
        return f"{path} (required result columns are missing: {', '.join(sorted(required - columns))})"
    return None


def _file_error(task: Task, path: Path, completed: bool) -> str | None:
    if not path.is_file():
        return f"{path} (result file is missing)"
    size = path.stat().st_size
    if not size:
        if _marker(path) or (completed and annotation_task_id(task.id) in EMPTY_SEARCH_TASKS):
            return None
        if task.id.startswith(("03.map.vamb.", "03.map.metabat2.")):
            empty = read_empty_binner(empty_mapping_marker(path))
            if empty is not None and empty["tool"] == task.id.split(".")[2]:
                return None
        return f"{path} (result file is empty)"
    if _marker(path):
        with path.open("rb") as handle:
            handle.read(1)
        return None
    name = path.name.lower()
    if name.endswith(FASTA_SUFFIXES):
        lines = [line.strip() for line in _head(path).splitlines() if line.strip()]
        if (len(lines) < 2 or not lines[0].startswith(">")
                or not lines[0][1:].strip() or lines[1].startswith(">")):
            return f"{path} (FASTA has no complete first sequence)"
    elif name.endswith(".bam"):
        with path.open("rb") as handle:
            header = handle.read(4)
            if header != b"BAM\x01":
                if header[:2] != b"\x1f\x8b" or size < len(BAM_EOF):
                    return f"{path} (BAM header is missing)"
                handle.seek(-len(BAM_EOF), 2)
                if handle.read() != BAM_EOF:
                    return f"{path} (BAM end-of-file block is missing)"
    elif name.endswith(".bai"):
        with path.open("rb") as handle:
            if size < 8 or handle.read(4) != b"BAI\x01":
                return f"{path} (BAM index header is missing)"
    elif name.endswith(".json"):
        if size <= 8 * 1024**2:
            with path.open("r", encoding="utf-8-sig") as handle:
                json.load(handle)
        else:
            with path.open("rb") as handle:
                start = handle.read(64).lstrip()
                handle.seek(-64, 2)
                end = handle.read().rstrip()
            if not start.startswith((b"{", b"[")) or not end.endswith((b"}", b"]")):
                return f"{path} (JSON result is truncated)"
    else:
        with path.open("rb") as handle:
            handle.read(1)
    if task.id in {"05.qc.checkm", "05.qc.checkm2"}:
        return _table_error(path, {"completeness", "contamination"})
    if task.id.startswith("02.annotation.coverm.") or task.id == "03.annotation.merge" and name.endswith(".tsv"):
        return _table_error(path, {"genome"})
    if task.id.endswith(".format") and ".annotation." in task.id and name.endswith(".tsv"):
        return _table_error(path, {"mag", "gene"})
    return None


def _directory_error(task: Task, path: Path, completed: bool) -> str | None:
    if not path.is_dir():
        return f"{path} (result directory is missing)"
    empty_binner = read_empty_binner(path)
    if empty_binner is not None:
        if (task.id.startswith(("03.bin.", "03.publish."))
                and empty_binner["tool"] != task.id.split(".")[2]):
            return f"{path} (zero-bin evidence belongs to another binner)"
        if any(item.is_file() and item.name.lower().endswith(FASTA_SUFFIXES) for item in path.rglob("*")):
            return f"{path} (zero-bin marker conflicts with FASTA files)"
        return None
    fasta_directory = (path in task.fasta_output_dirs or task.id.startswith("03.publish.") or path.name in {
        "candidate_bins", "filtered_bins", "representative_bins", "non_redundant_bins",
    })
    if fasta_directory:
        if task.allow_empty_refinement and read_empty_refinement(path) is not None:
            return None
        files = [item for item in path.rglob("*") if item.is_file() and item.name.lower().endswith(FASTA_SUFFIXES)]
        if not files:
            return f"{path} (no MAG FASTA files)"
        for fasta in files:
            error = _file_error(task, fasta, completed)
            if error:
                return error
        return None
    if task.id.startswith("01.annotation.gtdbtk"):
        tables = sorted(path.rglob("gtdbtk.*.summary.tsv"))
        if not tables:
            return f"{path} (GTDB-Tk classification summary is missing)"
        for table in tables:
            if table.stat().st_size:
                error = _table_error(table, {"user_genome", "classification"})
                if error:
                    return error
        if not any(table.stat().st_size for table in tables):
            return f"{path} (GTDB-Tk summaries are empty)"
        genomes = [item for item in task.inputs if item.name.lower().endswith(FASTA_SUFFIXES)]
        if genomes:
            from .internal import gtdbtk_result_missing
            missing = gtdbtk_result_missing(path, genomes)
            if missing:
                return f"{path} ({'; '.join(missing)})"
        return None
    if task.id == "05.qc.gunc":
        if not any(item.is_file() and item.stat().st_size for item in path.rglob("*maxCSS_level*.tsv")):
            return f"{path} (GUNC quality result is missing)"
        return None
    if task.id == "05.qc.rna_domain":
        if not any(item.is_file() and item.stat().st_size for item in path.rglob("*markers_summary.tsv")):
            return f"{path} (GTDB-Tk marker-domain result is missing)"
        return None
    if not any(item.is_file() and item.stat().st_size and not _marker(item)
               and item.suffix.lower() != ".log" for item in path.rglob("*")):
        return f"{path} (no final result files)"
    return None


def result_errors(task: Task, *, completed: bool = False) -> list[str]:
    """Return missing/broken final outputs; legacy completion markers are optional.

    Zero-hit native search files need only an old successful completion record
    or log footer, not matching command/input fingerprints. Header-only final
    annotation tables and certified zero-bin refinement results are valid.
    """
    if not (task.outputs or task.output_alternatives):
        return ["task has no declared results"]
    substantive = any(not _marker(path) for path in task.outputs) or bool(task.output_alternatives)
    paths = [path for path in task.outputs if not (substantive and _marker(path))]

    def error_for(path: Path) -> str | None:
        try:
            return (_directory_error(task, path, completed) if path.is_dir()
                    else _file_error(task, path, completed))
        except (OSError, ValueError, EOFError) as exc:
            return f"{path} (cannot read complete result: {exc})"

    errors = [error for path in paths if (error := error_for(path)) is not None]
    if task.output_alternatives:
        alternatives = [[error for path in group if (error := error_for(path)) is not None]
                        for group in task.output_alternatives]
        if all(alternatives):
            errors.extend(min(alternatives, key=len))
    if not errors and task.id == "03.annotation.merge":
        manifest = next((path for path in paths if path.name == "manifest.json"), None)
        if manifest is not None:
            try:
                values = json.loads(manifest.read_text(encoding="utf-8-sig"))
                for value in values.values():
                    if isinstance(value, str) and value.endswith((".tsv", ".txt", ".csv")):
                        # Manifest paths must stay under the owning CoverM directory.
                        member = manifest.parent / value
                        if member.name != value:
                            errors.append(f"{manifest} (invalid result filename)")
                            continue
                        if error := error_for(member):
                            errors.append(error)
            except (OSError, ValueError, AttributeError) as exc:
                errors.append(f"{manifest} (unreadable CoverM result manifest: {exc})")
        combined = next((path for path in paths if path.name.startswith("coverm_all_metrics")), None)
        if combined is not None:
            try:
                tokens = shlex.split(task.display_command())
                samples = {tokens[index + 1].split("=", 1)[0] for index, token in enumerate(tokens[:-1])
                           if token == "--input" and "=" in tokens[index + 1]}
                with combined.open("r", encoding="utf-8-sig") as handle:
                    columns = {value.split("|", 1)[0] for value in handle.readline().rstrip().split("\t")}
                if samples - columns:
                    errors.append(f"{combined} (sample abundance columns are missing)")
            except (OSError, ValueError) as exc:
                errors.append(f"{combined} (cannot read abundance columns: {exc})")
    return errors


def log_completed(path: Path | None) -> bool:
    """A small log-tail check can certify a legitimate zero-hit result."""
    if path is None:
        return False
    try:
        with path.open("rb") as handle:
            handle.seek(max(0, path.stat().st_size - 2048))
            tail = handle.read().decode("utf-8", errors="replace")
        codes = re.findall(r"^# exit_code: (\d+)\s*$", tail, re.M)
        return bool(codes and codes[-1] == "0" and "# validation_error:" not in tail)
    except OSError:
        return False
