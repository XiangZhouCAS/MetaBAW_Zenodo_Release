"""Guard the legacy MAGScoT empty merge before it loses its contig columns."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import tempfile


_EMPTY_MERGE_GUARD = (
    "# MetaBAW: keep existing bins when no eligible merge remains.\n"
    "if (nrow(bisco_out) == 0) {\n"
    '    cat("Exiting bin merging, no (more) overlaps found\\n")\n'
    "    break\n"
    "}\n"
)
_LEGACY_MERGE = re.compile(
    r"(?m)^(?P<assignment>[ \t]*bisco_out\s*=\s*binmatch[^\n]*\n)"
    r"(?P<indent>[ \t]*)(?=contig_to_bin_bisco_it\s*=\s*bisco_out\s*%>%[ \t]*apply\()"
)
_PROFILE_LOOKUP = re.compile(
    r"file\.path\(\s*funr::get_script_path\(\)\s*,\s*([\"'])profiles\1\s*,"
)


def guarded_magscot_source(source: str, script_directory: Path) -> str | None:
    """Adapt the known legacy merge block, leaving fixed/unknown code alone.

    The guard exits only the merge loop. Native scoring, refinement, marker
    requirements and contamination/completeness thresholds still run normally.
    Profile lookups retain the installed script's directory after relocation.
    """
    matches = list(_LEGACY_MERGE.finditer(source))
    if len(matches) != 1:
        return None
    match = matches[0]
    assignment = match.group("assignment")
    if not all(fragment in assignment for fragment in (
        "shared_markers >= min_markers", "seq_along(shared_markers)",
    )):
        return None
    if not re.search(
        r'left_join\(contig_to_bin_unique,\s*by\s*=\s*[\"\']contig[\"\']\)',
        source[match.end():],
    ) or "contig_to_bin_bisco = contig_to_bin" not in source:
        return None

    # Do not relocate scripts with other, unfamiliar script-relative resources.
    if "funr::get_script_path()" in _PROFILE_LOOKUP.sub("", source):
        return None
    indent = match.group("indent")
    guard = "".join(indent + line + "\n" for line in _EMPTY_MERGE_GUARD.splitlines())
    insertion = match.start("indent")
    patched = source[:insertion] + guard + source[insertion:]
    original_directory = json.dumps(script_directory.as_posix(), ensure_ascii=False)
    return _PROFILE_LOOKUP.sub(
        lambda _: f'file.path({original_directory}, "profiles",', patched,
    )


def prepare_magscot_command(
    command: list[str], workdir: Path,
) -> tuple[list[str], str | None]:
    """Run a private guarded script without changing the upstream installation."""
    if Path(command[0]).name.lower().removesuffix(".exe") != "rscript":
        return command, None
    if "--skip_merge_bins" in command or "--score_only" in command:
        return command, None
    script_index = next(
        (index for index in range(1, len(command)) if not command[index].startswith("-")),
        None,
    )
    if script_index is None or Path(command[script_index]).name.lower() != "magscot.r":
        return command, None
    script = Path(command[script_index]).expanduser()
    if not script.is_absolute():
        script = workdir / script
    script = script.resolve()
    if not script.is_file():
        return command, None
    patched = guarded_magscot_source(script.read_text(encoding="utf-8-sig"), script.parent)
    if patched is None:
        return command, None

    directory = workdir.resolve() / ".metabaw-magscot"
    directory.mkdir(parents=True, exist_ok=True)
    managed = directory / "MAGScoT.R"
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n", dir=directory,
        prefix=".pending-", suffix=".R", delete=False,
    ) as handle:
        pending = Path(handle.name)
        try:
            handle.write(patched)
        except BaseException:
            handle.close()
            pending.unlink(missing_ok=True)
            raise
    try:
        os.replace(pending, managed)
    finally:
        pending.unlink(missing_ok=True)
    prepared = command.copy()
    prepared[script_index] = str(managed)
    return prepared, (
        "[MAGScoT COMPAT] Guard empty merge combinations; retain existing bins "
        "for native scoring/refinement. "
        f"source={script}; managed_script={managed}"
    )
