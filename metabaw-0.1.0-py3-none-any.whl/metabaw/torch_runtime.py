"""Inspect the native PyTorch environment without importing GPU libraries.

This module is also loaded with runpy by isolated Python interpreters. Keep it
independent of the MetaBAW package and defer packaging imports until needed.
"""
import csv
from importlib import metadata
from email.parser import BytesParser
import importlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from types import SimpleNamespace
import zipfile


def _requirements(distribution, *, torch_only=False):
    try:
        from packaging.requirements import Requirement
    except ImportError:
        from pip._vendor.packaging.requirements import Requirement
    for value in distribution.requires or ():
        if torch_only and not re.match(r"(?i)^\s*torch(?:\s|[<>=!~;\[(]|$)", value):
            continue
        requirement = Requirement(value)
        if requirement.marker is None or requirement.marker.evaluate({"extra": ""}):
            yield requirement


def _name(value):
    return re.sub(r"[-_.]+", "-", value).lower()


def accepts_torch_version(requirements, version):
    """Respect PEP 508 spelling/markers instead of testing literal 'torch=='."""
    active = tuple(_requirements(SimpleNamespace(requires=requirements), torch_only=True))
    return bool(active) and all(requirement.specifier.contains(version, prereleases=True)
                                for requirement in active)


def dependency_issues(imported_version=None):
    """Check Torch's own requirements and installed packages that require Torch.

    A successful CUDA allocation alone cannot establish that SymPy or binary
    companions such as TorchAudio match the installed Torch release.
    """
    try:
        torch = metadata.distribution("torch")
    except metadata.PackageNotFoundError:
        return ()  # Source installs can have no Python distribution record.
    problems = []
    if imported_version and imported_version.split("+", 1)[0] != torch.version.split("+", 1)[0]:
        problems.append("imported torch %s differs from its distribution metadata %s; "
                        "check for overlapping installations" % (imported_version, torch.version))
    for requirement in _requirements(torch):
        try:
            installed = metadata.version(requirement.name)
        except metadata.PackageNotFoundError:
            installed = None
        if installed is None or not requirement.specifier.contains(installed, prereleases=True):
            problems.append("torch %s requires %s; installed %s" %
                            (torch.version, requirement, installed or "missing"))
    for distribution in metadata.distributions():
        if _name(distribution.metadata.get("Name", "")) == "torch":
            continue
        for requirement in _requirements(distribution, torch_only=True):
            if _name(requirement.name) == "torch" and not requirement.specifier.contains(torch.version, prereleases=True):
                problems.append("%s %s requires %s; installed torch %s" %
                                (distribution.metadata.get("Name"), distribution.version, requirement, torch.version))
    return tuple(dict.fromkeys(problems))


def wheel_requirements(version):
    """Repair existing companions together; do not add unused audio/vision tools.

    TorchAudio 2.11 uses the stable ABI and supports Torch >=2.11. The official
    Torch 2.13 profile therefore uses Audio 2.11, not a nonexistent Audio 2.13.
    """
    companions = {
        "2.6.0": {"torchvision": "0.21.0", "torchaudio": "2.6.0"},
        "2.13.0": {"torchvision": "0.28.0", "torchaudio": "2.11.0"},
    }[version]
    packages = ["torch==" + version]
    for name, companion_version in companions.items():
        try:
            metadata.version(name)
        except metadata.PackageNotFoundError:
            continue
        packages.append(name + "==" + companion_version)
    # Pip does not reconsider every already installed application. Refuse a
    # target that would break another application's declared Torch contract.
    for distribution in metadata.distributions():
        name = _name(distribution.metadata.get("Name", ""))
        if name in ("torch", *companions):
            continue
        for requirement in _requirements(distribution, torch_only=True):
            if _name(requirement.name) == "torch" and not requirement.specifier.contains(version, prereleases=True):
                raise RuntimeError("Cannot repair torch to %s: %s %s requires %s. "
                                   "Use separate environments for incompatible tools." %
                                   (version, distribution.metadata.get("Name"), distribution.version, requirement))
    return tuple(packages)


_MODULE_ROOTS = {"torch": {"torch", "torchgen", "functorch"},
                 "torchvision": {"torchvision", "torchvision.libs"},
                 "torchaudio": {"torchaudio", "torchaudio.libs", "torio"}}


def _package_sites():
    prefix = Path(sys.prefix).resolve()
    sites = {Path(sysconfig.get_path(key)).resolve() for key in ("purelib", "platlib")}
    if not all(site.is_relative_to(prefix) for site in sites):
        raise RuntimeError("Cannot safely locate the selected Python environment's package metadata")
    return prefix, sites


def _retire_old_metadata(expected, backup, wheel_members=None):
    """Retire private obsolete files/records, retaining linked shared resources.

    Plan all moves before touching files. A Conda RECORD can traverse links to
    shared headers/libraries; those files do not belong to this wheel cleanup.
    """
    prefix, sites = _package_sites()
    importlib.invalidate_caches()
    records = list(metadata.distributions())
    for name, version in expected.items():
        if not any(_name(row.metadata.get("Name", "")) == name and row.version == version for row in records):
            raise RuntimeError("The replacement wheel's metadata is missing: %s==%s" % (name, version))
    moves, sources, destinations, preserved = [], set(), set(), set()

    def plan(source, destination):
        source = source.resolve()
        if source in sources:
            return
        if (destination.exists() or destination.is_symlink() or destination in destinations
                or not destination.resolve().is_relative_to(backup.resolve())):
            raise RuntimeError("Cannot safely retire obsolete package path: %s" % source)
        sources.add(source)
        destinations.add(destination)
        moves.append((source, destination))

    for row in records:
        name = _name(row.metadata.get("Name", ""))
        if name not in expected or row.version == expected[name]:
            continue
        location = getattr(row, "_path", None)
        if location is None:
            raise RuntimeError("Cannot identify the obsolete %s metadata directory" % name)
        info = Path(location)
        if (info.is_symlink() or not info.is_dir() or info.resolve().parent not in sites
                or not info.name.endswith((".dist-info", ".egg-info"))):
            raise RuntimeError("Obsolete %s metadata is outside the selected environment: %s" % (name, info))
        # Retain a clean module tree when wheel layouts change (notably old
        # TorchAudio binary extensions). Only recorded files in these package
        # namespaces are owned here; shared Conda libraries are never removed.
        roots = _MODULE_ROOTS[name]
        for entry in (row.files or ()) if wheel_members is not None else ():
            relative = Path(str(entry))
            if not relative.parts or relative.parts[0] not in roots:
                continue
            if relative.is_absolute() or ".." in relative.parts:
                raise RuntimeError("Unsafe obsolete package file in %s metadata" % name)
            if relative.as_posix() in wheel_members[name]:
                continue
            obsolete = Path(row.locate_file(entry))
            if not obsolete.is_file() and not obsolete.is_symlink():
                continue
            module_root = (info.resolve().parent / relative.parts[0]).resolve()
            if (obsolete.is_symlink() or not module_root.is_relative_to(prefix)
                    or not obsolete.resolve().is_relative_to(module_root)):
                preserved.add(str(obsolete))
                continue
            retired = backup / "obsolete-files" / info.name / relative
            plan(obsolete, retired)
        destination = backup / info.name
        plan(info.resolve(), destination)
    moved = []
    try:
        for source, destination in moves:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(destination))
            moved.append((source, destination))
    except Exception:
        for source, destination in reversed(moved):
            if source.exists() or source.is_symlink():
                raise RuntimeError("Cannot restore retired package path after cleanup failure: %s" % source)
            source.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(destination), str(source))
        raise
    finally:
        importlib.invalidate_caches()
    if preserved:
        examples = [value if len(value) <= 180 else value[:177] + "..." for value in sorted(preserved)[:3]]
        print("[CUDA REPAIR] Preserved %d linked/shared obsolete package file(s): %s%s" %
              (len(preserved), "; ".join(examples), "; ..." if len(preserved) > 3 else ""), flush=True)


def _installed_wheel_members(expected):
    """Return inventories only for a complete, importable installed target set.

    This recovers an interrupted post-install cleanup without another large
    download. Verify in a child so native modules cannot stay cached across a
    subsequent reinstall. Incomplete payloads or dependencies use normal repair.
    """
    prefix, sites = _package_sites()
    importlib.invalidate_caches()
    records = list(metadata.distributions())
    selected, members = {}, {}
    for name, version in expected.items():
        # /home and /data can expose the same environment through aliases.
        rows = list({Path(getattr(row, "_path", "")).resolve(): row for row in records
                     if _name(row.metadata.get("Name", "")) == name and row.version == version}.values())
        if len(rows) != 1:
            return None
        row = rows[0]
        info = Path(getattr(row, "_path", ""))
        if (info.is_symlink() or not info.is_dir() or info.resolve().parent not in sites
                or not info.name.endswith(".dist-info") or not (info / "RECORD").is_file()):
            return None
        # Some importlib.metadata releases filter missing files out of .files.
        # Recovery must validate the full RECORD, including absent headers.
        record = row.read_text("RECORD")
        try:
            files = [entry[0] for entry in csv.reader(io.StringIO(record or "")) if entry]
        except csv.Error:
            return None
        if not files:
            return None
        inventory = {entry.replace("\\", "/") for entry in files}
        if name + "/__init__.py" not in inventory:
            return None
        for entry in files:
            relative = Path(str(entry))
            if not relative.parts or relative.parts[0] not in _MODULE_ROOTS[name]:
                continue
            if relative.is_absolute() or ".." in relative.parts:
                return None
            if relative.suffix == ".pyc":
                continue
            installed = Path(row.locate_file(entry))
            module_root = (info.resolve().parent / relative.parts[0]).resolve()
            if (not installed.is_file() or not module_root.is_relative_to(prefix)
                    or not installed.resolve().is_relative_to(module_root)):
                return None
        selected[name], members[name] = row, inventory
    # Ignore superseded records for these wheels, but honor every other tool's
    # active Torch contract and all dependencies of the actual target wheels.
    for row in records:
        name = _name(row.metadata.get("Name", ""))
        if name in expected and row is not selected[name]:
            continue
        for requirement in _requirements(row, torch_only=name not in expected):
            dependency = _name(requirement.name)
            try:
                version = expected[dependency] if dependency in expected else metadata.version(requirement.name)
            except metadata.PackageNotFoundError:
                return None
            if not requirement.specifier.contains(version, prereleases=True):
                return None
    probe = '''import importlib, json, sys, sysconfig
from pathlib import Path
prefix = Path(sys.prefix).resolve()
sites = {Path(sysconfig.get_path(key)).resolve() for key in ("purelib", "platlib")}
for name, version in json.loads(sys.argv[1]).items():
    module = importlib.import_module(name)
    if str(getattr(module, "__version__", "")) != version:
        raise RuntimeError("Imported version differs from selected wheel: " + name)
    origin = Path(module.__file__).resolve()
    if not origin.is_relative_to(prefix) or not any(origin.is_relative_to((site / name).resolve()) for site in sites):
        raise RuntimeError("Imported module is outside the selected package: " + name)
'''
    try:
        result = subprocess.run([sys.executable, "-B", "-c", probe, json.dumps(expected)],
                                capture_output=True, text=True, timeout=120)
    except (OSError, subprocess.SubprocessError):
        return None
    return members if result.returncode == 0 else None


def repair_cuda_wheels(requirements, index_url, cuda_tag):
    """Stage complete wheels; resolve dependencies before a bounded overlay.

    Conda Torch records can refer to missing headers, so pip's uninstall can
    fail partway through replacement. Only Torch and existing audio/vision
    wheels bypass uninstall; their dependencies still use normal resolution.
    """
    try:
        from packaging.requirements import Requirement
    except ImportError:
        from pip._vendor.packaging.requirements import Requirement
    if not re.fullmatch(r"cu[0-9]+", cuda_tag):
        raise ValueError("Invalid CUDA wheel tag")
    wanted = {}
    for value in requirements:
        match = re.fullmatch(r"(torch|torchvision|torchaudio)==([0-9.]+)", value)
        if not match or match[1] in wanted:
            raise ValueError("Invalid targeted PyTorch repair requirement: %s" % value)
        wanted[match[1]] = match[2] + "+" + cuda_tag
    if "torch" not in wanted:
        raise ValueError("PyTorch repair requires an explicit Torch target")
    pip = [sys.executable, "-m", "pip"]
    with tempfile.TemporaryDirectory(prefix="metabaw-torch-repair-") as temporary:
        directory = Path(temporary)
        backup = directory / "retired-metadata"
        backup.mkdir()
        installed_members = _installed_wheel_members(wanted)
        if installed_members is not None:
            print("[CUDA REPAIR] Selected CUDA wheels are already installed; completing metadata cleanup "
                  "without downloading packages.", flush=True)
            _retire_old_metadata(wanted, backup, installed_members)
            issues = dependency_issues(wanted["torch"])
            if issues:
                raise RuntimeError("PyTorch dependency repair remains incomplete: " + " | ".join(issues))
            return
        wheels = directory / "wheels"
        wheels.mkdir()
        selected = [name + "==" + version for name, version in wanted.items()]
        print("[CUDA REPAIR] Downloading the selected CUDA wheels and required dependencies.", flush=True)
        subprocess.run([*pip, "download", "--only-binary=:all:", "--dest", str(wheels),
                        "--index-url", index_url, *selected], check=True)
        paths, dependencies, wheel_members = {}, [], {}
        for wheel in sorted(wheels.glob("*.whl")):
            with zipfile.ZipFile(wheel) as archive:
                members = set(archive.namelist())
                entries = [name for name in members if name.endswith(".dist-info/METADATA")]
                if len(entries) != 1:
                    raise RuntimeError("Invalid wheel metadata: %s" % wheel.name)
                info = BytesParser().parsebytes(archive.read(entries[0]))
            name = _name(info.get("Name", ""))
            if name not in wanted:
                continue
            if info["Version"] != wanted[name] or name in paths:
                raise RuntimeError("Unexpected CUDA wheel version: %s" % wheel.name)
            paths[name] = wheel
            wheel_members[name] = members
            for raw in info.get_all("Requires-Dist", ()):
                requirement = Requirement(raw)
                if requirement.marker and not requirement.marker.evaluate({"extra": ""}):
                    continue
                dependency = _name(requirement.name)
                if dependency in wanted:
                    if not requirement.specifier.contains(wanted[dependency], prereleases=True):
                        raise RuntimeError("Selected CUDA wheels have conflicting requirements: %s" % requirement)
                    continue
                dependencies.append(str(requirement))
        if set(paths) != set(wanted):
            raise RuntimeError("The complete selected CUDA wheel set was not downloaded")
        if dependencies:
            print("[CUDA REPAIR] Resolving runtime dependencies with the staged wheels.", flush=True)
            subprocess.run([*pip, "install", "--no-index", "--find-links", str(wheels),
                            *dict.fromkeys(dependencies)], check=True)
        print("[CUDA REPAIR] Restoring only Torch and its selected companions; bypassing damaged uninstall records.", flush=True)
        subprocess.run([*pip, "install", "--ignore-installed", "--no-deps", "--no-index",
                        *(str(paths[name]) for name in wanted)], check=True)
        _retire_old_metadata(wanted, backup, wheel_members)
        issues = dependency_issues()
        if issues:
            raise RuntimeError("PyTorch dependency repair remains incomplete: " + " | ".join(issues))
