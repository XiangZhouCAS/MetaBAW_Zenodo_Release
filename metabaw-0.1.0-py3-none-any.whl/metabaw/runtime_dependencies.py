"""Side-effect-free startup/dependency probes and bounded Python repairs."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import tempfile

from .comebin_runtime import COMEBIN_PYTHON_VERSIONS, COMEBIN_VERSION
from .software_versions import PACKAGE_VERSIONS


# Help/version commands load native script dependencies without processing data.
CLI_PROBES = {
    "bash": ("--version",), "bowtie2": ("--version",),
    "bowtie2-build": ("--version",), "minimap2": ("--version",),
    "minibwa": ("version",), "samtools": ("--version",),
    "jgi_summarize_bam_contig_depths": ("--help",), "metabat2": ("--help",),
    "strobealign": ("--version",), "vamb": ("--help",),
    "metadecoder": ("--help",), "SemiBin2": ("--help",),
    "run_comebin.sh": ("-V",),
    "bedtools": ("--version",), "Rscript": ("--version",),
    "prodigal": ("-h",), "parallel": ("--version",),
    "hmmsearch": ("-h",), "hmmalign": ("-h",),
    "pplacer": ("--version",), "guppy": ("--version",),
    "skani": ("--version",), "DAS_Tool": ("-h",),
    "diamond": ("version",), "pullseq": ("-h",),
    "ruby": ("--version",), "perl": ("-e", "use strict; use warnings; print $^V;"),
    "checkm": ("--help",), "gunc": ("--help",),
    "gtdbtk": ("--version",), "tRNAscan-SE": ("-h",),
    "barrnap": ("--version",), "galah": ("--version",),
    "dRep": ("-h",), "coverm": ("--version",),
    "exec_annotation": ("--help",), "run_dbcan": ("--help",),
    "blastp": ("-version",), "makeblastdb": ("-version",),
    "git": ("--version",), "megahit": ("--version",), "flye": ("--help",),
}
PYTHON_DISTRIBUTIONS = {
    "vamb": "vamb", "SemiBin2": "SemiBin", "metadecoder": "metadecoder",
    "checkm": "CheckM-genome", "gunc": "gunc", "gtdbtk": "gtdbtk",
    "dRep": "drep", "run_dbcan": "dbcan", "megahit": "megahit", "flye": "flye",
}
# dRep lists its test runner in install_requires, but genome dereplication does
# not use it. Native startup errors are still reported even for this package.
NON_RUNTIME_REQUIREMENTS = {
    "drep": ("pytest",),
    # dbCAN declares these for diagnostic/session logging. Normal CAZyme
    # annotation does not use them; real imports below still detect a failure
    # if an installed release actually needs either package at runtime.
    "dbcan": ("importlib-metadata", "session-info"),
}
ANALYSIS_IMPORT_PROFILES = {
    # These are lazy imports in dbCAN 5's CAZyme_annotation path, shared by
    # releases 5.0.0 through 5.2.9. Importing them does not create processors,
    # open reference databases or start genome analysis.
    "dbcan": {"5": ("dbcan.IO.fasta", "dbcan.annotation.diamond",
                     "dbcan.annotation.pyhmmer_search", "dbcan.IO.OverviewGenerator")},
}
# Some Conda/source installs provide the real library without the obsolete PyPI
# forwarding distribution. Accept it only when its actual import succeeds.
REQUIREMENT_IMPORT_PROVIDERS = {
    "python-igraph": "igraph", "igraph": "igraph", "sklearn": "sklearn",
}
FATAL_MARKERS = (
    "traceback (most recent call last)", "modulenotfounderror", "importerror",
    "no module named", "cannot import name", "error while loading shared libraries",
    "undefined symbol", "symbol lookup error", "can't locate ", "cannot load such file",
    "loaderror", "there is no package called", "unable to load shared object",
    "execution halted", "segmentation fault", "bad interpreter", "cannot find config-metawrap",
)
MODULE_DISTRIBUTIONS = {
    "pyrodigal": "pyrodigal", "pyhmmer": "pyhmmer", "pycoverm": "pycoverm",
    "vambcore": "vambcore", "dadaptation": "dadaptation", "loguru": "loguru",
    "sklearn": "scikit-learn", "numpy": "numpy", "scipy": "scipy",
    "pandas": "pandas", "torch": "torch", "networkx": "networkx",
    "numba": "numba", "tqdm": "tqdm", "yaml": "PyYAML", "Bio": "biopython",
    "packaging": "packaging", "h5py": "h5py", "joblib": "joblib",
    "pysam": "pysam", "psutil": "psutil", "requests": "requests",
    "matplotlib": "matplotlib", "dendropy": "dendropy",
    "importlib_metadata": "importlib-metadata", "session_info": "session-info",
    "zipp": "zipp", "rich_click": "rich-click", "openpyxl": "openpyxl",
    "pycirclize": "pycirclize", "BCBio": "bcbio-gff",
    "hnswlib": "hnswlib", "igraph": "igraph", "leidenalg": "leidenalg",
    "tensorboard": "tensorboard", "biolib": "biolib", "checkm": "CheckM-genome",
    "tensorflow": "tensorflow", "keras": "keras", "lightgbm": "lightgbm",
}


def native_probe_healthy(process, executable: str) -> bool:
    text = "\n".join(part for part in (process.stdout, process.stderr) if part).lower()
    if any(marker in text for marker in FATAL_MARKERS):
        return False
    if process.returncode == 0:
        return True
    # Several native tools intentionally return 1/2 for help. Require genuine
    # usage text and no loader/import failure rather than accepting every exit.
    return (process.returncode in (1, 2) and executable not in PYTHON_DISTRIBUTIONS
            and ("usage:" in text or "usage: " in text or "options:" in text))


def import_failure_packages(output: str) -> tuple[str, ...]:
    # Python 2.7 omits quotation marks. Isolated probes may report several
    # independent import errors; retain each known distribution only once.
    modules = re.findall(r"No module named\s+['\"]?([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)", output)
    return tuple(dict.fromkeys(MODULE_DISTRIBUTIONS[root] for name in modules
                               if (root := name.split(".")[0]) in MODULE_DISTRIBUTIONS))


def metadata_probe_code(distribution: str) -> str:
    """Audit selected distribution requirements inside its native Python.

    Metadata is inspected without importing CUDA or starting tool analysis.
    Optional extras/false environment markers are excluded. Declared exact
    dependency versions are used for repair, not to reject a working stack.
    """
    return (
        "import json, sys\n"
        f"non_runtime = {NON_RUNTIME_REQUIREMENTS.get(distribution.lower(), ())!r}\n"
        f"import_providers = {REQUIREMENT_IMPORT_PROVIDERS!r}\n"
        f"analysis_profiles = {ANALYSIS_IMPORT_PROFILES.get(distribution.lower(), {})!r}\n"
        "try:\n"
        "    from importlib import metadata\n"
        "except ImportError:\n"
        "    try: import importlib_metadata as metadata\n"
        "    except ImportError:\n"
        "        import pkg_resources\n"
        "        class Distribution(object):\n"
        "            def __init__(self, dist):\n"
        "                self.requires = [str(q) for q in dist.requires()]\n"
        "                self.metadata = {'Name': dist.project_name}\n"
        "                self.version = dist.version\n"
        "        class Metadata(object):\n"
        "            PackageNotFoundError = pkg_resources.DistributionNotFound\n"
        "            @staticmethod\n"
        "            def version(name): return pkg_resources.get_distribution(name).version\n"
        "            @staticmethod\n"
        "            def distribution(name): return Distribution(pkg_resources.get_distribution(name))\n"
        "            @staticmethod\n"
        "            def distributions(): return (Distribution(dist) for dist in pkg_resources.working_set)\n"
        "        metadata = Metadata()\n"
        "r = {'python': sys.executable, 'prefix': sys.prefix, 'missing': [], 'requirements': {}, 'pins': [], 'runtime_errors': []}\n"
        "try:\n"
        f"    d = metadata.distribution({distribution!r})\n"
        "except metadata.PackageNotFoundError:\n"
        "    d = None\n"
        "if d is not None:\n"
        "    r['tool_version'] = d.version\n"
        "    raw = d.requires or []\n"
        "    if raw:\n"
        "        try:\n"
        "            from packaging.requirements import Requirement\n"
        "        except ImportError:\n"
        "            try: from pip._vendor.packaging.requirements import Requirement\n"
        "            except ImportError: from pkg_resources.extern.packaging.requirements import Requirement\n"
        "        for value in raw:\n"
        "            q = Requirement(value)\n"
        "            if q.marker is not None and not q.marker.evaluate({'extra': ''}): continue\n"
        "            key = q.name.lower().replace('_', '-').replace('.', '-')\n"
        "            if key in non_runtime: continue\n"
        "            r['requirements'][key] = str(q.name) + str(q.specifier)\n"
        "            try: metadata.version(q.name)\n"
        "            except metadata.PackageNotFoundError:\n"
        "                provider = import_providers.get(key)\n"
        "                if provider:\n"
        "                    try:\n"
        "                        __import__(provider)\n"
        "                        continue\n"
        "                    except Exception: pass\n"
        "                r['missing'].append(q.name)\n"
        "    for name in analysis_profiles.get(d.version.split('.')[0], ()):\n"
        "        try: __import__(name, fromlist=['*'])\n"
        "        except Exception as exc: r['runtime_errors'].append('%s: %s: %s' % (name, type(exc).__name__, exc))\n"
        # Freeze the full native environment for bounded dependency repairs, not
        # just Torch/NumPy: dbCAN also shares Pyrodigal, PyHMMER and many others.
        "for installed in metadata.distributions():\n"
        "    name = installed.metadata.get('Name')\n"
        "    if name and installed.version: r['pins'].append(name + '==' + installed.version)\n"
        "r['pins'] = sorted(set(r['pins']))\n"
        "print('METABAW_DEPENDENCIES=' + json.dumps(r, sort_keys=True))\n"
    )


def python_dependency_metadata(launcher: list[str], distribution: str) -> dict:
    process = subprocess.run([*launcher, "-c", metadata_probe_code(distribution)],
                             capture_output=True, text=True, check=False, timeout=30)
    marker = "METABAW_DEPENDENCIES="
    for line in reversed(process.stdout.splitlines()):
        if line.startswith(marker) and process.returncode == 0:
            payload = json.loads(line[len(marker):])
            if isinstance(payload, dict) and isinstance(payload.get("missing"), list):
                return payload
    detail = (process.stderr or process.stdout or "no dependency status returned").strip()
    raise RuntimeError(f"Python dependency metadata probe failed: {detail[-1000:]}")


def repair_python_dependencies(executable: str, distribution: str,
                               packages: tuple[str, ...], environment: dict,
                               *, launcher: list[str] | None = None):
    from .metadecoder_coverage import _python_launcher

    launcher = launcher if launcher is not None else _python_launcher(executable)
    payload = python_dependency_metadata(launcher, distribution)
    requirements = payload.get("requirements", {})
    installed_pins = {
        re.sub(r"[-_.]+", "-", pin.split("==", 1)[0]).lower(): pin
        for pin in payload.get("pins", ()) if "==" in pin
    }
    selected = []
    restore = []
    missing = {re.sub(r"[-_.]+", "-", name).lower() for name in payload["missing"]}
    for name in dict.fromkeys(packages):
        normalized = re.sub(r"[-_.]+", "-", name).lower()
        if normalized.startswith(("torch", "cupy")):
            raise RuntimeError(f"{name} requires the existing dedicated GPU/runtime repair; "
                               "Python dependency repair will not replace that stack")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", name):
            raise ValueError(f"Invalid dependency name: {name}")
        requirement = requirements.get(normalized, name)
        if normalized in installed_pins and normalized not in missing:
            # A distribution record can survive deletion/corruption of its
            # import files. Restore its installed version, even when upstream
            # has a stricter pin; repairing one import must not downgrade it.
            requirement = installed_pins[normalized]
            restore.append(requirement)
        selected.append(requirement)
    if not selected:
        raise ValueError("No missing Python dependencies selected")
    with tempfile.TemporaryDirectory(prefix="metabaw-python-dependencies-") as directory:
        constraints = Path(directory) / "constraints.txt"
        constraints.write_text("\n".join(payload.get("pins", ())) + "\n", encoding="utf-8")
        if restore:
            restored = subprocess.run([*launcher, "-m", "pip", "install", "--force-reinstall",
                                       "--no-deps", "--constraint", str(constraints), *restore],
                                      check=False, env=environment)
            if restored.returncode:
                return restored
        return subprocess.run([*launcher, "-m", "pip", "install", "--constraint",
                               str(constraints), *selected], check=False, env=environment)


def isolated_probe_code(key: str, executable: str, python_version: str, *, search_path: str | None = None) -> str:
    """Python 2.7-compatible probe for each selected isolated environment."""
    # Import the installed tool's real analysis entry points. Their dependency
    # trees vary across releases; a broad third-party checklist can reject an
    # otherwise healthy environment for an unused/optional module.
    modules = {
        "comebin": ("torch",),
        "checkm2": ("checkm2.predictQuality",),
        # MetaBAW invokes bin_refinement, not quant_bins/other MetaWRAP modules.
        # Its helper needs SeqIO; CheckM's real main module loads its own actual
        # dependency tree. Pandas is not an unconditional refinement dependency.
        "metawrap": ("Bio.SeqIO", "checkm.main"),
        "lorbin": ("lorbin.lorbin", "torch"),
    }[key]
    externals = {
        "comebin": ("bash", "bedtools", "samtools", "hmmsearch", "prodigal",
                    "checkm", "perl", "run_FragGeneScan.pl"),
        "checkm2": ("diamond",),
        "metawrap": ("bash", "config-metawrap", "checkm", "prodigal", "hmmsearch", "hmmalign", "pplacer"),
        "lorbin": ("bedtools", "samtools", "hmmsearch", "prodigal"),
    }[key]
    supported_python = COMEBIN_PYTHON_VERSIONS if key == "comebin" else (python_version,)
    package = {"comebin": "comebin", "checkm2": "checkm2", "metawrap": "metawrap-refinement", "lorbin": "lorbin"}[key]
    expected_version = PACKAGE_VERSIONS[package]
    executable_line = (f"executable = which({executable!r}, path={search_path!r})" if search_path is not None
                       else f"executable = which({executable!r})")
    return (
        "import json, sys, os, subprocess, glob, re\n"
        "try:\n"
        "    from shutil import which\n"
        "except ImportError:\n"
        "    from distutils.spawn import find_executable as which\n"
        f"{executable_line}\n"
        "version = '%s.%s' % (sys.version_info[0], sys.version_info[1])\n"
        "errors = []\n"
        f"if executable and version in {supported_python!r}:\n"
        f"    for name in {modules!r}:\n"
        "        try:\n"
        "            module = __import__(name, fromlist=['*'])\n"
        "            if name == 'torch': module.zeros(1)\n"
        "        except Exception as exc: errors.append('%s: %s: %s' % (name, type(exc).__name__, exc))\n"
        f"    for name in {externals!r}:\n"
        "        if which(name) is None: errors.append('required executable missing: ' + name)\n"
        f"    if {key!r} == 'comebin':\n"
        "        try:\n"
        "            import torch\n"
        "            from torch.amp import GradScaler, autocast\n"
        "            torch_version = tuple(int(part) for part in torch.__version__.split('+')[0].split('.')[:2])\n"
        "            if not (2, 13) <= torch_version < (2, 14):\n"
        "                errors.append('COMEBin 1.1.0 requires pytorch>=2.13,<2.14; found ' + torch.__version__)\n"
        "        except Exception as exc: errors.append('COMEBin torch.amp: %s: %s' % (type(exc).__name__, exc))\n"
        "        base = os.path.dirname(os.path.realpath(executable))\n"
        "        roots = [base, os.path.join(base, 'COMEBin')]\n"
        "        root = next((p for p in roots if os.path.isfile(os.path.join(p, 'main.py'))), None)\n"
        "        if root is None: errors.append('COMEBin/main.py cannot be found beside its launcher')\n"
        "        else:\n"
        "            sys.path.insert(0, root)\n"
        "            try:\n"
        "                from comebin_version import __version__ as tool_version\n"
        f"                if tool_version != {COMEBIN_VERSION!r}: errors.append('COMEBin version ' + str(tool_version) + '; expected {COMEBIN_VERSION}')\n"
        "            except Exception as exc: errors.append('COMEBin version: %s: %s' % (type(exc).__name__, exc))\n"
        "            for name in ('main', 'get_final_result', 'data_aug.generate_augfasta_and_saveindex', 'data_aug.gen_cov'):\n"
        "                try: __import__(name, fromlist=['*'])\n"
        "                except Exception as exc: errors.append('COMEBin %s: %s: %s' % (name, type(exc).__name__, exc))\n"
        f"    if {key!r} in ('checkm2', 'metawrap'):\n"
        "        try:\n"
        "            p = subprocess.Popen([executable, '--help'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)\n"
        "            out, err = p.communicate()\n"
        "            text = (out + err).decode('utf-8', 'replace')\n"
        f"            if p.returncode or any(marker in text.lower() for marker in {FATAL_MARKERS!r}): errors.append('native startup: ' + text[-1500:])\n"
        "        except Exception as exc: errors.append('native startup: %s: %s' % (type(exc).__name__, exc))\n"
        f"    if {key!r} != 'comebin':\n"
        "        tool_version = None\n"
        "        try:\n"
        "            from importlib import metadata as native_metadata\n"
        f"            tool_version = native_metadata.version({package!r})\n"
        "        except Exception: pass\n"
        "        if tool_version is None:\n"
        f"            for record in glob.glob(os.path.join(sys.prefix, 'conda-meta', {package!r} + '-*.json')):\n"
        "                try:\n"
        "                    with open(record) as handle: data = json.load(handle)\n"
        f"                    if data.get('name', '').lower() == {package!r}: tool_version = data.get('version')\n"
        "                except Exception: pass\n"
        f"        if tool_version is None and {key!r} == 'metawrap':\n"
        "            match = re.search(r'(?i)metaWRAP[^0-9\\r\\n]*v?([0-9]+(?:\\.[0-9]+)+)', locals().get('text', ''))\n"
        "            if match: tool_version = match.group(1)\n"
        "        normalized = str(tool_version).split('.') if tool_version else []\n"
        "        while normalized and normalized[-1] == '0': normalized.pop()\n"
        f"        wanted = {expected_version!r}.split('.')\n"
        "        while wanted and wanted[-1] == '0': wanted.pop()\n"
        f"        if normalized != wanted: errors.append({key!r} + ' version ' + str(tool_version or 'unknown') + '; expected {expected_version}')\n"
        "print(json.dumps({'python': version, 'executable': executable, "
        "'runtime_error': '; '.join(errors) if errors else None}))\n"
    )
