"""Side-effect-free startup/dependency probes and bounded Python repairs."""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import tempfile


# Help/version commands load native script dependencies without processing data.
CLI_PROBES = {
    "bash": ("--version",), "bowtie2": ("--version",),
    "bowtie2-build": ("--version",), "minimap2": ("--version",),
    "minibwa": ("--help",), "samtools": ("--version",),
    "jgi_summarize_bam_contig_depths": ("--help",), "metabat2": ("--help",),
    "strobealign": ("--version",), "vamb": ("--help",),
    "metadecoder": ("--help",), "SemiBin2": ("--help",),
    "bedtools": ("--version",), "Rscript": ("--version",),
    "prodigal": ("-h",), "parallel": ("--version",),
    "hmmsearch": ("-h",), "hmmalign": ("-h",),
    "pplacer": ("--version",), "guppy": ("--version",),
    "skani": ("--version",), "DAS_Tool": ("-h",),
    "diamond": ("version",), "pullseq": ("-h",),
    "ruby": ("--version",), "perl": ("-e", "use strict; use warnings; print $^V;"),
    "checkm": ("--help",), "gunc": ("--help",),
    "gtdbtk": ("--version",), "tRNAscan-SE": ("-h",),
    "barrnap": ("--version",), "galah": ("--version",),
    "dRep": ("-h",), "coverm": ("--version",),
    "exec_annotation": ("--help",), "run_dbcan": ("--help",),
    "blastp": ("-version",), "makeblastdb": ("-version",),
    "git": ("--version",), "megahit": ("--version",), "flye": ("--help",),
}
PYTHON_DISTRIBUTIONS = {
    "vamb": "vamb", "SemiBin2": "SemiBin", "metadecoder": "metadecoder",
    "checkm": "CheckM-genome", "gunc": "gunc", "gtdbtk": "gtdbtk",
    "dRep": "drep", "run_dbcan": "dbcan", "megahit": "megahit", "flye": "flye",
}
# dRep lists its test runner in install_requires, but genome dereplication does
# not use it. Native startup errors are still reported even for this package.
NON_RUNTIME_REQUIREMENTS = {"drep": ("pytest",)}
# Some Conda/source installs provide the real library without the obsolete PyPI
# forwarding distribution. Accept it only when its actual import succeeds.
REQUIREMENT_IMPORT_PROVIDERS = {
    "python-igraph": "igraph", "igraph": "igraph", "sklearn": "sklearn",
}
FATAL_MARKERS = (
    "traceback (most recent call last)", "modulenotfounderror", "importerror",
    "no module named", "cannot import name", "error while loading shared libraries",
    "undefined symbol", "symbol lookup error", "can't locate ", "cannot load such file",
    "loaderror", "there is no package called", "unable to load shared object",
    "execution halted", "segmentation fault", "bad interpreter", "cannot find config-metawrap",
)
PROTECTED_PACKAGES = (
    "torch", "numpy", "scipy", "pandas", "scikit-learn", "cupy",
    "cupy-cuda11x", "cupy-cuda12x", "cupy-cuda13x",
)
MODULE_DISTRIBUTIONS = {
    "pyrodigal": "pyrodigal", "pyhmmer": "pyhmmer", "pycoverm": "pycoverm",
    "vambcore": "vambcore", "dadaptation": "dadaptation", "loguru": "loguru",
    "sklearn": "scikit-learn", "numpy": "numpy", "scipy": "scipy",
    "pandas": "pandas", "torch": "torch", "networkx": "networkx",
    "numba": "numba", "tqdm": "tqdm", "yaml": "PyYAML", "Bio": "biopython",
    "packaging": "packaging", "h5py": "h5py", "joblib": "joblib",
    "pysam": "pysam", "psutil": "psutil", "requests": "requests",
    "matplotlib": "matplotlib", "dendropy": "dendropy",
}


def native_probe_healthy(process, executable: str) -> bool:
    text = "\n".join(part for part in (process.stdout, process.stderr) if part).lower()
    if any(marker in text for marker in FATAL_MARKERS):
        return False
    if process.returncode == 0:
        return True
    # Several native tools intentionally return 1/2 for help. Require genuine
    # usage text and no loader/import failure rather than accepting every exit.
    return (process.returncode in (1, 2) and executable not in PYTHON_DISTRIBUTIONS
            and ("usage:" in text or "usage: " in text or "options:" in text))


def import_failure_packages(output: str) -> tuple[str, ...]:
    match = re.search(r"No module named ['\"]([^'\"]+)['\"]", output)
    root = match.group(1).split(".")[0] if match else None
    package = MODULE_DISTRIBUTIONS.get(root)
    return (package,) if package else ()


def metadata_probe_code(distribution: str) -> str:
    """Audit selected distribution requirements inside its native Python.

    Metadata is inspected without importing CUDA or starting tool analysis.
    Optional extras/false environment markers are excluded. Declared exact
    dependency versions are used for repair, not to reject a working stack.
    """
    return (
        "import json, sys\n"
        f"non_runtime = {NON_RUNTIME_REQUIREMENTS.get(distribution.lower(), ())!r}\n"
        f"import_providers = {REQUIREMENT_IMPORT_PROVIDERS!r}\n"
        "try:\n"
        "    from importlib import metadata\n"
        "except ImportError:\n"
        "    try: import importlib_metadata as metadata\n"
        "    except ImportError:\n"
        "        import pkg_resources\n"
        "        class Metadata(object):\n"
        "            PackageNotFoundError = pkg_resources.DistributionNotFound\n"
        "            @staticmethod\n"
        "            def version(name): return pkg_resources.get_distribution(name).version\n"
        "            @staticmethod\n"
        "            def distribution(name):\n"
        "                dist = pkg_resources.get_distribution(name)\n"
        "                class Distribution(object):\n"
        "                    requires = [str(q) for q in dist.requires()]\n"
        "                return Distribution()\n"
        "        metadata = Metadata()\n"
        "r = {'python': sys.executable, 'prefix': sys.prefix, 'missing': [], 'requirements': {}, 'pins': []}\n"
        "try:\n"
        f"    d = metadata.distribution({distribution!r})\n"
        "except metadata.PackageNotFoundError:\n"
        "    d = None\n"
        "if d is not None:\n"
        "    raw = d.requires or []\n"
        "    if raw:\n"
        "        try:\n"
        "            from packaging.requirements import Requirement\n"
        "        except ImportError:\n"
        "            try: from pip._vendor.packaging.requirements import Requirement\n"
        "            except ImportError: from pkg_resources.extern.packaging.requirements import Requirement\n"
        "        for value in raw:\n"
        "            q = Requirement(value)\n"
        "            if q.marker is not None and not q.marker.evaluate({'extra': ''}): continue\n"
        "            key = q.name.lower().replace('_', '-').replace('.', '-')\n"
        "            if key in non_runtime: continue\n"
        "            r['requirements'][key] = str(q.name) + str(q.specifier)\n"
        "            try: metadata.version(q.name)\n"
        "            except metadata.PackageNotFoundError:\n"
        "                provider = import_providers.get(key)\n"
        "                if provider:\n"
        "                    try:\n"
        "                        __import__(provider)\n"
        "                        continue\n"
        "                    except Exception: pass\n"
        "                r['missing'].append(q.name)\n"
        f"for name in {PROTECTED_PACKAGES!r}:\n"
        "    try: r['pins'].append(name + '==' + metadata.version(name))\n"
        "    except metadata.PackageNotFoundError: pass\n"
        "print('METABAW_DEPENDENCIES=' + json.dumps(r, sort_keys=True))\n"
    )


def python_dependency_metadata(launcher: list[str], distribution: str) -> dict:
    process = subprocess.run([*launcher, "-c", metadata_probe_code(distribution)],
                             capture_output=True, text=True, check=False, timeout=30)
    marker = "METABAW_DEPENDENCIES="
    for line in reversed(process.stdout.splitlines()):
        if line.startswith(marker) and process.returncode == 0:
            payload = json.loads(line[len(marker):])
            if isinstance(payload, dict) and isinstance(payload.get("missing"), list):
                return payload
    detail = (process.stderr or process.stdout or "no dependency status returned").strip()
    raise RuntimeError(f"Python dependency metadata probe failed: {detail[-1000:]}")


def repair_python_dependencies(executable: str, distribution: str,
                               packages: tuple[str, ...], environment: dict):
    from .metadecoder_coverage import _python_launcher

    launcher = _python_launcher(executable)
    payload = python_dependency_metadata(launcher, distribution)
    requirements = payload.get("requirements", {})
    selected = []
    restore = []
    missing = {re.sub(r"[-_.]+", "-", name).lower() for name in payload["missing"]}
    for name in dict.fromkeys(packages):
        normalized = re.sub(r"[-_.]+", "-", name).lower()
        if normalized.startswith(("torch", "cupy")):
            raise RuntimeError(f"{name} requires the existing dedicated GPU/runtime repair; "
                               "Python dependency repair will not replace that stack")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", name):
            raise ValueError(f"Invalid dependency name: {name}")
        requirement = requirements.get(normalized, name)
        selected.append(requirement)
        if normalized in requirements and normalized not in missing:
            # A distribution record can survive deletion/corruption of its
            # import files. Ordinary pip install would only say "satisfied".
            restore.append(requirement)
    if not selected:
        raise ValueError("No missing Python dependencies selected")
    with tempfile.TemporaryDirectory(prefix="metabaw-python-dependencies-") as directory:
        constraints = Path(directory) / "constraints.txt"
        constraints.write_text("\n".join(payload.get("pins", ())) + "\n", encoding="utf-8")
        if restore:
            restored = subprocess.run([*launcher, "-m", "pip", "install", "--force-reinstall",
                                       "--no-deps", "--constraint", str(constraints), *restore],
                                      check=False, env=environment)
            if restored.returncode:
                return restored
        return subprocess.run([*launcher, "-m", "pip", "install", "--constraint",
                               str(constraints), *selected], check=False, env=environment)


def isolated_probe_code(key: str, executable: str, python_version: str) -> str:
    """Python 2.7-compatible probe for each selected isolated environment."""
    # Import the installed tool's real analysis entry points. Their dependency
    # trees vary across releases; a broad third-party checklist can reject an
    # otherwise healthy environment for an unused/optional module.
    modules = {
        "comebin": ("torch",),
        "checkm2": ("checkm2.predictQuality",),
        # MetaBAW invokes bin_refinement, not quant_bins/other MetaWRAP modules.
        # Its helper needs SeqIO; CheckM's real main module loads its own actual
        # dependency tree. Pandas is not an unconditional refinement dependency.
        "metawrap": ("Bio.SeqIO", "checkm.main"),
        "lorbin": ("lorbin.lorbin", "torch"),
    }[key]
    externals = {
        "comebin": ("bash", "bedtools", "samtools", "hmmsearch", "prodigal",
                    "checkm", "perl", "run_FragGeneScan.pl"),
        "checkm2": ("diamond",),
        "metawrap": ("bash", "config-metawrap", "checkm", "prodigal", "hmmsearch", "hmmalign", "pplacer"),
        "lorbin": ("bedtools", "samtools", "hmmsearch", "prodigal"),
    }[key]
    return (
        "import json, sys, os, subprocess\n"
        "try:\n"
        "    from shutil import which\n"
        "except ImportError:\n"
        "    from distutils.spawn import find_executable as which\n"
        f"executable = which({executable!r})\n"
        "version = '%s.%s' % (sys.version_info[0], sys.version_info[1])\n"
        "errors = []\n"
        f"if executable and version == {python_version!r}:\n"
        f"    for name in {modules!r}:\n"
        "        try:\n"
        "            module = __import__(name, fromlist=['*'])\n"
        "            if name == 'torch': module.zeros(1)\n"
        "        except Exception as exc: errors.append('%s: %s: %s' % (name, type(exc).__name__, exc))\n"
        f"    for name in {externals!r}:\n"
        "        if which(name) is None: errors.append('required executable missing: ' + name)\n"
        f"    if {key!r} == 'comebin':\n"
        "        base = os.path.dirname(os.path.realpath(executable))\n"
        "        roots = [base, os.path.join(base, 'COMEBin')]\n"
        "        root = next((p for p in roots if os.path.isfile(os.path.join(p, 'main.py'))), None)\n"
        "        if root is None: errors.append('COMEBin/main.py cannot be found beside its launcher')\n"
        "        else:\n"
        "            sys.path.insert(0, root)\n"
        "            for name in ('main', 'get_final_result', 'data_aug.generate_augfasta_and_saveindex', 'data_aug.gen_cov'):\n"
        "                try: __import__(name, fromlist=['*'])\n"
        "                except Exception as exc: errors.append('COMEBin %s: %s: %s' % (name, type(exc).__name__, exc))\n"
        f"    if {key!r} in ('checkm2', 'metawrap'):\n"
        "        try:\n"
        "            p = subprocess.Popen([executable, '--help'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)\n"
        "            out, err = p.communicate()\n"
        "            text = (out + err).decode('utf-8', 'replace')\n"
        f"            if p.returncode or any(marker in text.lower() for marker in {FATAL_MARKERS!r}): errors.append('native startup: ' + text[-1500:])\n"
        "        except Exception as exc: errors.append('native startup: %s: %s' % (type(exc).__name__, exc))\n"
        "print(json.dumps({'python': version, 'executable': executable, "
        "'runtime_error': '; '.join(errors) if errors else None}))\n"
    )
