"""Read required reference assets before any workflow tasks start.

The GTDB-Tk inventory runs this file under GTDB-Tk's own Python. Keep imports
standard-library-only so that its installed configuration remains authoritative.
"""
from __future__ import annotations

import csv
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


def _file_issue(path: Path) -> str | None:
    try:
        with path.open("rb") as handle:
            if not handle.read(1):
                return f"{path} (empty)"
    except OSError as exc:
        return f"{path} ({exc})"
    return None


def _raise_issues(issues: list[str]) -> None:
    if issues:
        detail = "; ".join(issues[:20])
        if len(issues) > 20:
            detail += f"; and {len(issues) - 20} more missing/invalid assets"
        raise RuntimeError("missing/invalid reference assets: " + detail)


def _hmm_issue(path: Path) -> str | None:
    issue = _file_issue(path)
    if issue:
        return issue
    try:
        with path.open("rb") as handle:
            header = handle.readline(256)
            handle.seek(max(0, path.stat().st_size - 256))
            tail = handle.read().rstrip()
        if not header.startswith((b"HMMER3/", b"HMMER2.")):
            return f"{path} (not a HMMER profile)"
        if not tail.endswith(b"//"):
            return f"{path} (truncated HMMER profile; missing // terminator)"
    except OSError as exc:
        return f"{path} ({exc})"
    return None


def validate_hmm_assets(paths) -> None:
    _raise_issues([issue for path in paths if (issue := _hmm_issue(Path(path)))])


def validate_checkm_assets(directory: Path) -> None:
    issues = []
    entries = 0
    with (directory / ".dmanifest").open(encoding="utf-8") as handle:
        for number, raw in enumerate(handle, 1):
            if not raw.strip() or raw.startswith("#"):
                continue
            fields = raw.rstrip().split("\t")
            if len(fields) != 3:
                issues.append(f".dmanifest line {number}: expected path, hash and size")
                continue
            entries += 1
            path = directory / fields[0]
            if fields[1] == "-":
                if not path.is_dir():
                    issues.append(f"{path} (missing directory listed in .dmanifest)")
                continue
            try:
                expected_size = int(fields[2])
                with path.open("rb") as reference:
                    reference.read(1)
                if expected_size < 0 or path.stat().st_size != expected_size:
                    issues.append(f"{path} (size differs from .dmanifest; incomplete download)")
            except ValueError:
                issues.append(f".dmanifest line {number}: invalid file size")
            except OSError as exc:
                issues.append(f"{path} ({exc})")
    if not entries:
        issues.append(".dmanifest has no reference file entries")
    _raise_issues(issues)
    validate_hmm_assets((directory / "hmms" / "phylo.hmm", directory / "hmms" / "checkm.hmm"))


def validate_kofam_assets(directory: Path) -> None:
    issues = []
    required = set()
    with (directory / "ko_list").open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        reader.fieldnames = [name.strip().lstrip("#") for name in (reader.fieldnames or [])]
        if not {"knum", "threshold", "score_type"} <= set(reader.fieldnames):
            raise RuntimeError(f"{directory / 'ko_list'} lacks knum/threshold/score_type columns")
        for number, row in enumerate(reader, 2):
            ko = row.get("knum", "")
            threshold = row.get("threshold", "")
            score_type = row.get("score_type", "")
            if not ko or not re.fullmatch(r"K\d{5}", ko):
                issues.append(f"ko_list line {number}: invalid KO identifier")
                continue
            if threshold in {"-", "NA", ""}:
                continue
            try:
                valid = math.isfinite(float(threshold)) and score_type in {"full", "domain"}
            except (ValueError, TypeError):
                valid = False
            if not valid:
                issues.append(f"ko_list line {number}: invalid threshold/score_type for {ko}")
            else:
                required.add(ko)
    if not required:
        issues.append("ko_list has no usable KO thresholds")
    for ko in sorted(required):
        if issue := _hmm_issue(directory / "profiles" / f"{ko}.hmm"):
            issues.append(issue)
    _raise_issues(issues)


def validate_diamond_database(path: Path, run_prefix=()) -> None:
    """Use the DIAMOND executable that will consume this database."""
    command = [*run_prefix, "diamond", "dbinfo", "--db", str(path)]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, check=False, timeout=60)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "DIAMOND could not load the database").strip()
        raise RuntimeError(f"{path}: DIAMOND database load failed: {detail[-4000:]}")


def validate_protein_fasta(path: Path) -> None:
    identifier = None
    has_sequence = False
    issues = []
    with path.open(encoding="utf-8-sig") as handle:
        for number, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line or line.startswith(";"):
                continue
            if line.startswith(">"):
                if identifier is not None and not has_sequence:
                    issues.append(f"{path}: {identifier} has no protein sequence")
                identifier = line[1:].strip()
                has_sequence = False
                if not identifier:
                    issues.append(f"{path} line {number}: empty FASTA identifier")
            elif identifier is None or not re.fullmatch(r"[A-Za-z*.-]+", line):
                issues.append(f"{path} line {number}: invalid protein FASTA content")
            else:
                has_sequence = True
    if identifier is None:
        issues.append(f"{path}: no FASTA records")
    elif not has_sequence:
        issues.append(f"{path}: {identifier} has no protein sequence")
    _raise_issues(issues)


def _reference_package_issues(directory: Path) -> list[str]:
    manifest = directory / "CONTENTS.json"
    if issue := _file_issue(manifest):
        return [issue]
    try:
        files = json.loads(manifest.read_text(encoding="utf-8"))["files"]
        if not isinstance(files, dict) or not files:
            raise ValueError("empty files inventory")
        return [issue for value in files.values()
                if (issue := _file_issue(directory / value))]
    except (KeyError, TypeError, ValueError) as exc:
        return [f"{manifest}: invalid reference-package inventory ({exc})"]


def _validate_gtdb_inventory(directory: Path, config, classification: bool) -> None:
    """Use the installed GTDB-Tk release's filenames and marker lists."""
    version = config.VERSION_DATA
    if version not in config.COMPATIBLE_REF_DATA_VERSIONS:
        raise RuntimeError(f"GTDB-Tk reference release {version!r} is incompatible; "
                           f"expected {config.COMPATIBLE_REF_DATA_VERSIONS}")
    if (not isinstance(config.RED_DIST_BAC_DICT, dict) or not config.RED_DIST_BAC_DICT
            or not isinstance(config.RED_DIST_ARC_DICT, dict) or not config.RED_DIST_ARC_DICT):
        raise RuntimeError("GTDB-Tk metadata.txt lacks valid RED_DIST_BAC_DICT/RED_DIST_ARC_DICT")
    hmm_paths = {Path(config.TIGRFAM_HMMS), Path(config.PFAM_HMM_DIR) / "Pfam-A.hmm"}
    marker_roots = {
        "PFAM": Path(config.PFAM_HMM_DIR) / "individual_hmms",
        "TIGRFAM": Path(config.TIGRFAM_HMMS).parent / "individual_hmms",
    }
    for markers in (config.BAC120_MARKERS, config.AR53_MARKERS):
        for source, names in markers.items():
            hmm_paths.update(marker_roots[source] / name for name in names)
    issues = [issue for path in sorted(hmm_paths) if (issue := _hmm_issue(path))]
    if issue := _file_issue(Path(config.PFAM_HMM_DIR) / "Pfam-A.hmm.dat"):
        issues.append(issue)
    if classification:
        required_files = [
            config.TAXONOMY_FILE, config.RADII_FILE, config.CONCAT_BAC120, config.CONCAT_AR53,
            Path(config.MASK_DIR) / config.MASK_BAC120, Path(config.MASK_DIR) / config.MASK_AR53,
            config.MRCA_RED_BAC120, config.MRCA_RED_AR53,
            config.CLASS_LEVEL_TREE_MAPPING_FILE, config.BACKBONE_RED_FILE,
        ]
        issues.extend(issue for value in required_files if (issue := _file_issue(Path(value))))
        packages = [
            Path(config.PPLACER_DIR) / config.PPLACER_AR53_REF_PKG,
            Path(config.BACKBONE_PPLACER_DIR) / config.BACKBONE_PPLACER_REF_PKG,
        ]
        mapping = Path(config.CLASS_LEVEL_TREE_MAPPING_FILE)
        if _file_issue(mapping) is None:
            tree_ids = set()
            for number, raw in enumerate(mapping.read_text(encoding="utf-8").splitlines(), 1):
                fields = raw.split()
                if len(fields) != 2 or not re.fullmatch(r"[A-Za-z0-9_-]+", fields[1]):
                    issues.append(f"{mapping} line {number}: invalid class-to-tree mapping")
                else:
                    tree_ids.add(fields[1])
            if not tree_ids:
                issues.append(f"{mapping}: no class reference trees")
            for tree_id in sorted(tree_ids):
                packages.append(Path(config.CLASS_LEVEL_PPLACER_DIR)
                                / config.CLASS_LEVEL_PPLACER_REF_PKG.format(iter=tree_id))
                required_files = Path(config.CLASS_LEVEL_RED_FILE.format(iter=tree_id))
                if issue := _file_issue(required_files):
                    issues.append(issue)
        for package in packages:
            issues.extend(_reference_package_issues(package))
        sketches = Path(config.SKANI_SKETCHDB)
        if not sketches.is_dir() or not any(
            candidate.is_file() and _file_issue(candidate) is None for candidate in sketches.rglob("*")
        ):
            issues.append(f"{sketches}: missing/empty skani sketch database")
    _raise_issues(issues)


def validate_gtdb_database(directory: Path, *, classification: bool) -> None:
    from .metadecoder_coverage import _python_launcher
    from .dependencies import software_executable

    executable = software_executable("gtdbtk")
    if executable is None:
        raise RuntimeError("GTDB-Tk is unavailable for reference inventory validation")
    try:
        launcher = _python_launcher(executable)
    except ValueError as exc:
        raise RuntimeError(f"Cannot identify GTDB-Tk's Python launcher: {executable}") from exc
    command = [*launcher, "-B", str(Path(__file__).resolve()), str(directory)]
    if classification:
        command.append("--classification")
    environment = os.environ.copy()
    environment["GTDBTK_DATA_PATH"] = str(directory)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, check=False, timeout=120, env=environment)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "GTDB-Tk reference inventory could not be loaded").strip()
        raise RuntimeError(f"{directory}: {detail[-8000:]}")


if __name__ == "__main__":
    try:
        from gtdbtk.config.common import CONFIG
        _validate_gtdb_inventory(Path(sys.argv[1]), CONFIG, "--classification" in sys.argv[2:])
    except (OSError, RuntimeError, ValueError, TypeError, AttributeError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
