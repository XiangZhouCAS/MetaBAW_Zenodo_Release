"""User-selected executable versions, independent of database releases."""
import re


PACKAGE_VERSIONS = {
    "megahit": "1.2.9", "flye": "2.9.6", "bowtie2": "2.5.4", "minimap2": "2.28",
    "minibwa": "0.3-r399-dirty", "samtools": "1.21", "strobealign": "0.14.0", "metabat2": "2.12.1",
    "vamb": "5.0.4", "metadecoder": "1.2.2", "semibin": "2.4.0",
    "comebin": "1.1.0", "lorbin": "0.1.0", "das_tool": "1.1.7",
    "metawrap-refinement": "1.3.0", "checkm2": "1.1.0", "checkm-genome": "1.2.5",
    "gunc": "1.1.1", "trnascan-se": "2.0.9", "barrnap": "1.10.6", "galah": "0.4.2",
    "drep": "3.7.1", "gtdbtk": "2.7.2", "coverm": "0.7.0", "prodigal": "2.6.3",
    "kofamscan": "1.3.0", "dbcan": "5.2.9", "blast": "2.17.0", "diamond": "2.1.24",
    "hmmer": "3.4", "pullseq": "1.0.2",
}


def pinned_package(package: str) -> str:
    name = re.split(r"[<>=!~\s]", package, maxsplit=1)[0]
    version = PACKAGE_VERSIONS.get(name.lower())
    return f"{name}={version}" if version else package


def banner_version(output: str) -> str | None:
    """Read a native version banner without confusing help examples with it."""
    token = r"([0-9]+(?:\.[0-9]+){1,3}(?:b[0-9]+)?(?:-r[0-9]+(?:-dirty)?)?)"
    for line in output.splitlines()[:30]:
        for pattern in (r"(?i)\bversion\s*[:=]?\s*v?" + token,
                        r"(?i)^\s*#?\s*[\w.+-]+:?\s+[vV]?" + token + r"(?:\b|[-+])",
                        r"^\s*v?" + token + r"(?:\b|[-+])"):
            match = re.search(pattern, line)
            if match:
                return match[1]
    return None


def versions_equal(found: str | None, expected: str) -> bool:
    if found is None:
        return False
    # Native BLAST banners append '+', and Minimap2 appends a revision suffix.
    found = found.strip().lstrip("v").split("+")[0]
    if "-r" not in expected:
        found = found.split("-r")[0]
    if re.fullmatch(r"\d+(?:\.\d+)*", found) and re.fullmatch(r"\d+(?:\.\d+)*", expected):
        left, right = found.split("."), expected.split(".")
        size = max(len(left), len(right))
        return left + ["0"] * (size-len(left)) == right + ["0"] * (size-len(right))
    return found == expected
