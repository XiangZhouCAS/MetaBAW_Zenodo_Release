"""Evidence for native binners that explicitly completed with zero bins."""
from __future__ import annotations

import json
from pathlib import Path
import re


EMPTY_BINNER_MARKER = ".metabaw.binner-empty.json"
FASTA_SUFFIXES = (".fa", ".fna", ".fasta", ".fa.gz", ".fna.gz", ".fasta.gz")
EMPTY_REASONS = {"vamb": "no_bins_above_minimum_size", "metabat2": "no_bins_formed"}


def empty_mapping_marker(mapping: Path) -> Path:
    return mapping.with_name(mapping.name + ".empty.json")


def read_empty_binner(path: Path) -> dict | None:
    marker = path / EMPTY_BINNER_MARKER if path.is_dir() else path
    if not marker.is_file():
        return None
    payload = json.loads(marker.read_text(encoding="utf-8"))
    if (not isinstance(payload, dict) or payload.get("schema") != 1
            or type(payload.get("bin_count")) is not int or payload["bin_count"] != 0
            or not isinstance(payload.get("tool"), str) or payload["tool"] not in EMPTY_REASONS
            or payload.get("reason") != EMPTY_REASONS[payload["tool"]]):
        raise ValueError(f"Invalid zero-bin completion evidence: {marker}")
    return payload


def write_empty_binner(path: Path, tool: str = "vamb") -> None:
    reason = EMPTY_REASONS[tool]
    path.mkdir(parents=True, exist_ok=True)
    (path / EMPTY_BINNER_MARKER).write_text(json.dumps({
        "schema": 1, "tool": tool, "bin_count": 0, "reason": reason,
    }, sort_keys=True) + "\n", encoding="utf-8")


def certify_empty_vamb(bins: Path, log_path: Path | None = None) -> bool:
    if bins.is_dir() and any(path.is_file() and path.name.lower().endswith(FASTA_SUFFIXES)
                             for path in bins.rglob("*")):
        return False
    if bins.is_dir() and (empty := read_empty_binner(bins)) is not None:
        return empty["tool"] == "vamb"
    cluster_files = (bins.parent / "vae_clusters_unsplit.tsv", bins.parent / "clusters.tsv")
    if not any(path.is_file() and path.stat().st_size for path in cluster_files):
        return False
    for path in (bins.parent / "log.txt", log_path):
        if path is None or not path.is_file():
            continue
        with path.open("rb") as handle:
            handle.seek(max(0, path.stat().st_size - 8192))
            tail = handle.read().decode("utf-8", errors="replace")
        if re.search(r"Wrote 0 bins with 0 sequences", tail) and "Completed Vamb in" in tail:
            write_empty_binner(bins)
            return True
    return False


def certify_empty_metabat2(bins: Path, log_path: Path | None = None) -> bool:
    """Require the native zero-bin summary AND its successful process footer.

    Old MetaBAW versions rejected zero bins and deleted their empty directory.
    A surviving native-success log can restore that result without rerunning
    MetaBAT2. A plain empty directory, interrupted log or nonzero exit cannot.
    """
    if bins.exists() and not bins.is_dir():
        return False
    if bins.is_dir():
        if any(path.is_file() and path.name.lower().endswith(FASTA_SUFFIXES)
               for path in bins.rglob("*")):
            return False
        if (empty := read_empty_binner(bins)) is not None:
            return empty["tool"] == "metabat2"
    if log_path is None or not log_path.is_file():
        return False
    with log_path.open("rb") as handle:
        handle.seek(max(0, log_path.stat().st_size - 16384))
        tail = handle.read().decode("utf-8", errors="replace")
    exits = list(re.finditer(r"^# exit_code: (-?\d+)[ \t]*\r?$", tail, re.M))
    if not exits or exits[-1][1] != "0":
        return False
    native_output = tail[:exits[-1].start()]
    summaries = re.findall(
        r"^[ \t]*(\d+) bins \((\d+) bases in total\) formed\.[ \t]*\r?$",
        native_output, re.M,
    )
    if (not summaries or any(counts != ("0", "0") for counts in summaries)
            or "# workflow_abort:" in tail or "[Error!]" in native_output):
        return False
    write_empty_binner(bins, "metabat2")
    return True


def certify_empty_binner(tool: str, bins: Path, log_path: Path | None = None) -> bool:
    certifier = {"vamb": certify_empty_vamb, "metabat2": certify_empty_metabat2}.get(tool)
    return certifier(bins, log_path) if certifier else False


def empty_binner_message(payload: dict) -> str:
    return ("MetaBAT2 completed normally; 0 bins (0 bases in total) formed"
            if payload["tool"] == "metabat2"
            else "VAMB completed; no bins met the minimum FASTA size")
