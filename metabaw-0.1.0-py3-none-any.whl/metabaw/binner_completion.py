"""Evidence for a native VAMB run that completed with no size-qualified bins."""
from __future__ import annotations

import json
from pathlib import Path
import re


EMPTY_BINNER_MARKER = ".metabaw.binner-empty.json"
FASTA_SUFFIXES = (".fa", ".fna", ".fasta", ".fa.gz", ".fna.gz", ".fasta.gz")


def empty_mapping_marker(mapping: Path) -> Path:
    return mapping.with_name(mapping.name + ".empty.json")


def read_empty_binner(path: Path) -> dict | None:
    marker = path / EMPTY_BINNER_MARKER if path.is_dir() else path
    if not marker.is_file():
        return None
    payload = json.loads(marker.read_text(encoding="utf-8"))
    if (not isinstance(payload, dict) or payload.get("schema") != 1
            or type(payload.get("bin_count")) is not int or payload["bin_count"] != 0
            or payload.get("tool") != "vamb" or payload.get("reason") != "no_bins_above_minimum_size"):
        raise ValueError(f"Invalid zero-bin completion evidence: {marker}")
    return payload


def write_empty_binner(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    (path / EMPTY_BINNER_MARKER).write_text(json.dumps({
        "schema": 1, "tool": "vamb", "bin_count": 0,
        "reason": "no_bins_above_minimum_size",
    }, sort_keys=True) + "\n", encoding="utf-8")


def certify_empty_vamb(bins: Path, log_path: Path | None = None) -> bool:
    if bins.is_dir() and any(path.is_file() and path.name.lower().endswith(FASTA_SUFFIXES)
                             for path in bins.rglob("*")):
        return False
    if bins.is_dir() and read_empty_binner(bins) is not None:
        return True
    cluster_files = (bins.parent / "vae_clusters_unsplit.tsv", bins.parent / "clusters.tsv")
    if not any(path.is_file() and path.stat().st_size for path in cluster_files):
        return False
    for path in (bins.parent / "log.txt", log_path):
        if path is None or not path.is_file():
            continue
        with path.open("rb") as handle:
            handle.seek(max(0, path.stat().st_size - 8192))
            tail = handle.read().decode("utf-8", errors="replace")
        if re.search(r"Wrote 0 bins with 0 sequences", tail) and "Completed Vamb in" in tail:
            write_empty_binner(bins)
            return True
    return False
